# =========================================================================
#  BUILD PCODE Grapher Ghidra plugin (Java) — KHONG can Maven.
#  CHINH $GHIDRA (hoac set $env:GHIDRA) thanh duong dan Ghidra 12.1.3 cua ban.
# =========================================================================
$ErrorActionPreference = 'Stop'

$GHIDRA = if ($env:GHIDRA_INSTALL_DIR) { $env:GHIDRA_INSTALL_DIR } elseif ($env:GHIDRA) { $env:GHIDRA } else { $null }
if (-not $GHIDRA -or -not (Test-Path $GHIDRA)) { Write-Host "[ERR] Set GHIDRA_INSTALL_DIR (or GHIDRA) to a valid Ghidra directory." -ForegroundColor Red; exit 1 }

# Locate javac
$jc = Get-Command javac -ErrorAction SilentlyContinue
if (-not $jc) {
  if ($env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\javac.exe")) {
    $javac = "$env:JAVA_HOME\bin\javac.exe"
  } else {
    Write-Host "[ERR] Khong thay 'javac'. Them JDK 21 vao PATH hoac set JAVA_HOME." -ForegroundColor Red; exit 1
  }
} else {
  $javac = $jc.Source
}

# Locate jar (resolves shortcut paths if installed via Oracle javapath)
$jarCmd = Get-Command jar -ErrorAction SilentlyContinue
if ($jarCmd) {
  $jar = $jarCmd.Source
} elseif ($env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\jar.exe")) {
  $jar = "$env:JAVA_HOME\bin\jar.exe"
} else {
  $resolvedJavac = (Get-Item $javac).Target
  if ($resolvedJavac) {
    $jar = Join-Path (Split-Path $resolvedJavac -Parent) 'jar.exe'
  } else {
    $jar = Join-Path (Split-Path $javac -Parent) 'jar.exe'
  }
}

if (-not (Test-Path $jar)) {
  Write-Host "[ERR] Khong tim thay jar.exe tai: $jar" -ForegroundColor Red
  exit 1
}

Write-Host "[1/5] Thu thap classpath tu $GHIDRA ..."
$jars = Get-ChildItem -Path $GHIDRA -Filter '*.jar' -Recurse | Select-Object -ExpandProperty FullName
$cp = ($jars -join ';')
Set-Content -Path compile.arg -Encoding ASCII -Value @(
  '--release','21','-encoding','UTF-8','-proc:none','-d','target\classes','-cp',$cp,
  'src\main\java\com\pcodegrapher\PcodeGrapherPlugin.java',
  'src\main\java\com\pcodegrapher\Json.java'
)
Write-Host "        Tim thay $($jars.Count) jar."

Write-Host "[2/5] Bien dich (javac) ..."
New-Item -ItemType Directory -Force -Path target\classes | Out-Null
& $javac '@compile.arg'
if ($LASTEXITCODE -ne 0) { Write-Host "[ERR] Bien dich that bai (xem loi tren)." -ForegroundColor Red; exit 1 }

Write-Host "[3/5] Tao jar ..."
if (Test-Path target\PcodeGrapherBridge.jar) { Remove-Item target\PcodeGrapherBridge.jar }
& $jar --create --file=target\PcodeGrapherBridge.jar -C target\classes .
if ($LASTEXITCODE -ne 0) { Write-Host "[ERR] tao jar that bai." -ForegroundColor Red; exit 1 }

Write-Host "[4/5] Lap cau truc extension (folder PcodeGrapherBridge/) ..."
if (Test-Path target\dist) { Remove-Item -Recurse -Force target\dist }
New-Item -ItemType Directory -Force -Path target\dist\PcodeGrapherBridge\lib | Out-Null
Copy-Item target\PcodeGrapherBridge.jar target\dist\PcodeGrapherBridge\lib\
Copy-Item Module.manifest      target\dist\PcodeGrapherBridge\
Copy-Item extension.properties target\dist\PcodeGrapherBridge\

Write-Host "[5/5] Tao extension ZIP (dung 'jar -M' de CO directory entries) ..."
$ver = '1.7.0'
$zip = "target\PcodeGrapherBridge-$ver.zip"   # hardcode 1.6.2 -> mỗi lần bump là script tìm nhầm file
if (Test-Path $zip) { Remove-Item $zip }
# QUAN TRONG: KHONG dung Compress-Archive (PowerShell) - no tao zip THIEU directory
# entries -> Ghidra Extension Manager bao loi "FileNotFoundException ... extension.properties".
# Dung 'jar -M' (JDK) thay: jar luon tao directory entries -> install sach.
& $jar cMf $zip -C target\dist PcodeGrapherBridge

Remove-Item compile.arg -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "XONG!" -ForegroundColor Green
Write-Host "Cai dat:  $PWD\$zip"
Write-Host ""
Write-Host "NEU Extension Manager bao loi 'FileNotFoundException ... extension.properties':" -ForegroundColor Yellow
Write-Host "  -> KHONG cai qua GUI. Dong Ghidra roi copy thu muc NAY:" -ForegroundColor Yellow
Write-Host "     $PWD\target\dist\PcodeGrapherBridge" -ForegroundColor Yellow
Write-Host "     vao:  `$env:APPDATA\ghidra\ghidra_12.1.3_PUBLIC\Extensions\" -ForegroundColor Yellow
Write-Host "  -> Mo Ghidra -> CodeBrowser -> File -> Configure -> tim PcodeGrapherPlugin" -ForegroundColor Yellow
Write-Host ""
Write-Host "Kiem tra zip co directory entry khong (phai in ra PcodeGrapherBridge/ ):"
Write-Host "  jar tf `"$zip`" | Select-String '/$'"
