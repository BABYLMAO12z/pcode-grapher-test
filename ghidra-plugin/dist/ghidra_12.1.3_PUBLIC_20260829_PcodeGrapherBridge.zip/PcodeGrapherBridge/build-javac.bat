@echo off
setlocal enabledelayedexpansion

REM === CHINH DUONG DAN GHIDRA 12.1.3 CUA BAN O DAY (hoac set bien moi truong GHIDRA) ===
if "%GHIDRA%"=="" set "GHIDRA=%GHIDRA_INSTALL_DIR%"
set "VER=1.7.0"
set "OUT=target\classes"
set "DIST=target\dist"
set "PKG=PcodeGrapherBridge"

if not exist "%GHIDRA%" ( echo [ERR] Set GHIDRA_INSTALL_DIR ^(or GHIDRA^) to your Ghidra installation directory. & goto :end )
where javac >nul 2>nul || ( echo [ERR] Khong thay 'javac'. Cai JDK 21 roi them vao PATH. & goto :end )
where jar >nul 2>nul || ( echo [ERR] Khong thay 'jar'. Them JDK 21 bin vao PATH. & goto :end )

echo [1/5] Thu thap classpath tu %GHIDRA% ...
if exist compile.arg del compile.arg >nul
>compile.arg echo --release 21
>>compile.arg echo -encoding UTF-8
>>compile.arg echo -proc:none
>>compile.arg echo -d %OUT%
>>compile.arg echo -cp

set "NJAR=0"
if exist cp.tmp del cp.tmp >nul
for /r "%GHIDRA%" %%F in (*.jar) do (
    <nul set /p "=%%F;" >> cp.tmp
    set /a NJAR+=1
)
type cp.tmp >> compile.arg
if exist cp.tmp del cp.tmp >nul

>>compile.arg echo.
>>compile.arg echo src\main\java\com\pcodegrapher\PcodeGrapherPlugin.java
>>compile.arg echo src\main\java\com\pcodegrapher\Json.java
echo       da tim !NJAR! jar.

echo [2/5] Bien dich ...
if not exist %OUT% mkdir %OUT%
call javac @compile.arg
if errorlevel 1 ( echo [ERR] Bien dich that bai. Sua loi tren roi chay lai. & goto :end )
echo       OK.

echo [3/5] Dong goi jar ...
if exist target\%PKG%.jar del target\%PKG%.jar >nul
call jar --create --file=target\%PKG%.jar -C %OUT% .
if errorlevel 1 ( echo [ERR] tao jar that bai. & goto :end )
echo       OK.

echo [4/5] Lap cau truc extension Ghidra ...
if exist %DIST% rmdir /s /q %DIST%
mkdir %DIST%\PcodeGrapherBridge\lib
copy /y target\%PKG%.jar %DIST%\PcodeGrapherBridge\lib\ >nul
copy /y Module.manifest      %DIST%\PcodeGrapherBridge\ >nul
copy /y extension.properties %DIST%\PcodeGrapherBridge\ >nul

echo [5/5] Tao extension ZIP (dung "jar -M" de CO directory entries) ...
set "ZIP=target\%PKG%-%VER%.zip"
if exist "%ZIP%" del "%ZIP%" >nul
REM  QUAN TRONG: KHONG dung "Compress-Archive" (PowerShell) - no tao zip THIEU
REM  directory entries -> Ghidra Extension Manager bao loi
REM  "FileNotFoundException ... extension.properties". Dung "jar -M" (JDK) thay.
call jar cMf "%ZIP%" -C %DIST% PcodeGrapherBridge
if errorlevel 1 ( echo [ERR] tao zip that bai. & goto :end )

echo.
echo ===============================================================
echo  XONG.
echo  Cai dat: %CD%\%ZIP%
echo.
echo  LUU Y: Neu Extension Manager bao loi "FileNotFoundException
echo  ... extension.properties" thi KHONG cai qua GUI ma LAM THEO NAY:
echo    1) Dong Ghidra.
echo    2) Copy thu muc NAY:
echo       %CD%\%DIST%\PcodeGrapherBridge
echo       vao:  %%APPDATA%%\ghidra\ghidra_12.1.3_PUBLIC\Extensions\
echo    3) Mo Ghidra -^> CodeBrowser -^> File -^> Configure -^> tim PcodeGrapherPlugin
echo  (Xem TROUBLESHOOTING.md de biet nguyen nan tu source Ghidra.)
echo ===============================================================
echo  Kiem tra zip co directory entry khong:
echo     jar tf "%ZIP%" ^| findstr "/$"
echo  (neu in ra PcodeGrapherBridge/ va PcodeGrapherBridge/lib/ = zip DUNG)
:end
endlocal
