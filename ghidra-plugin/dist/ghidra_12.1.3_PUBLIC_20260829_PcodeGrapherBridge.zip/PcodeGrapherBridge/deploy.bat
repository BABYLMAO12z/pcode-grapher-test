@echo off
setlocal
REM Copy an already-built JAR into an installed extension. No compilation occurs here.
if "%GHIDRA_EXTENSIONS_DIR%"=="" set "GHIDRA_EXTENSIONS_DIR=%APPDATA%\ghidra\ghidra_12.1.3_PUBLIC\Extensions"
set "DST=%GHIDRA_EXTENSIONS_DIR%\PcodeGrapherBridge\lib"
if not exist "build\libs\PcodeGrapherBridge.jar" ( echo [!] No build\libs\PcodeGrapherBridge.jar. Run build.bat first. & goto :end )
if not exist "%DST%" ( echo [!] Extension is not installed at %DST%. Set GHIDRA_EXTENSIONS_DIR if your Ghidra profile has a different name. & goto :end )
copy /y "build\libs\PcodeGrapherBridge.jar" "%DST%\" >nul
if errorlevel 1 ( echo [ERR] Copy failed. & goto :end )
echo Done. Restart Ghidra to apply the update.
:end
endlocal
